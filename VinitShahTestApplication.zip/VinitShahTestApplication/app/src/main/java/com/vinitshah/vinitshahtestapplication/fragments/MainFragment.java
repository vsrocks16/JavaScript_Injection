package com.vinitshah.vinitshahtestapplication.fragments;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.vinitshah.vinitshahtestapplication.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class MainFragment extends Fragment {

    private Button btnOpen;
    private EditText etUsername;
    private EditText etPassword;
    private Listener mListener;

    public interface Listener {

        void onOpenButtonDialogClicked(String userName, String password);
    }

    public MainFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etUsername = (EditText) view.findViewById(R.id.etUsername);
        etPassword = (EditText) view.findViewById(R.id.etPassword);
        btnOpen = (Button) view.findViewById(R.id.btnOpen);

        btnOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (verifyFields()) {
                    if (mListener != null) {
                        mListener.onOpenButtonDialogClicked(etUsername.getText().toString(), etPassword.getText().toString());
                    }
                }
            }
        });
    }

    private boolean verifyFields() {
        if (TextUtils.isEmpty(etUsername.getText().toString())) {
            etUsername.setError("Please enter username.");
            return false;
        }

        if (TextUtils.isEmpty(etPassword.getText().toString())) {
            etPassword.setError("Please enter password.");
            return false;
        }
        return true;
    }

    public void setListener(Listener listener) {
        mListener = listener;
    }
}

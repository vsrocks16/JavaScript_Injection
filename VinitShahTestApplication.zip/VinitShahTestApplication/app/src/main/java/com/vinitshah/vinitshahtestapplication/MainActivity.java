package com.vinitshah.vinitshahtestapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.vinitshah.vinitshahtestapplication.fragments.MainFragment;

public class MainActivity extends AppCompatActivity implements MainFragment.Listener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setTitle("Dashboard");

        MainFragment mainFragment = new MainFragment();
        mainFragment.setListener(this);

        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.container_main_activity, mainFragment)
                .commit();
    }

    @Override
    public void onOpenButtonDialogClicked(String userName, String password) {
        Intent intent = new Intent(this, WebViewActivity.class);
        intent.putExtra(WebViewActivity.INTENT_EXTRA_USER_NAME, userName);
        intent.putExtra(WebViewActivity.INTENT_EXTRA_PASSWORD, password);
        startActivity(intent);
    }
}

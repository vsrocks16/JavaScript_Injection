package com.vinitshah.vinitshahtestapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.vinitshah.vinitshahtestapplication.fragments.WebViewFragment;

public class WebViewActivity extends AppCompatActivity {

    public static final String INTENT_EXTRA_USER_NAME = "INTENT_EXTRA_USER_NAME";
    public static final String INTENT_EXTRA_PASSWORD = "INTENT_EXTRA_PASSWORD";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Web View Activity");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        String userName = getIntent().getStringExtra(INTENT_EXTRA_USER_NAME);
        String password = getIntent().getStringExtra(INTENT_EXTRA_PASSWORD);

        WebViewFragment webViewFragment = WebViewFragment.newInstance(userName, password);
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.container_web_view_activity, webViewFragment)
                .commit();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            finish(); // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }
}
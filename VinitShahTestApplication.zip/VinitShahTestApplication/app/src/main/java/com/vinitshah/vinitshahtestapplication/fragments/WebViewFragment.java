package com.vinitshah.vinitshahtestapplication.fragments;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.vinitshah.vinitshahtestapplication.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class WebViewFragment extends Fragment {


    private static final String ARG_USER_NAME = "ARG_USER_NAME";
    private static final String ARG_PASSWORD = "ARG_PASSWORD";
    private String url = "https://www.facebook.com/";
    private String mUsername;
    private String mPassword;
    private WebView myWebView;
    private ProgressBar mProgressBar;

    public WebViewFragment() {
        // Required empty public constructor
    }

    public static WebViewFragment newInstance(String userName, String password) {
        WebViewFragment webViewFragment = new WebViewFragment();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_USER_NAME, userName);
        bundle.putString(ARG_PASSWORD, password);
        webViewFragment.setArguments(bundle);
        return webViewFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mUsername = getArguments().getString(ARG_USER_NAME);
            mPassword = getArguments().getString(ARG_PASSWORD);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_web_view, container, false);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mProgressBar = (ProgressBar) view.findViewById(R.id.progressBar1);
        myWebView = (WebView) view.findViewById(R.id.webview);
        myWebView.setWebChromeClient(new WebChromeClient());
        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.getSettings().setDomStorageEnabled(true);
//        myWebView.addJavascriptInterface(new JavaScriptInterface(getContext()), "Android");

        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                if (mProgressBar.getVisibility() == View.VISIBLE) {
                    mProgressBar.setVisibility(View.GONE);
                }

                StringBuilder sb = new StringBuilder();
                sb.append("(function() {");
                sb.append("     var x = document.getElementById(\"m_login_email\").value = '" + mUsername + "';");
                sb.append("     var pwd = document.querySelector(\"input[type= password]\").value  = '" + mPassword + "';");
                sb.append("})();");

                view.loadUrl("javascript:" + sb.toString());
            }
        });

        mProgressBar.setVisibility(View.VISIBLE);
        myWebView.loadUrl(url);
    }
}
